/*======================================================================
 FILE: icalgauge.c
 CREATOR: eric 23 December 1999

 SPDX-FileCopyrightText: 2000, Eric Busboom <eric@civicknowledge.com>
 SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0

 The Original Code is eric. The Initial Developer of the Original
 Code is Eric Busboom
======================================================================*/

/**
 * @file icalgauge.c
 * @brief Routines implementing a filter for ical components
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "icalgauge.h"
#include "icalgaugeimpl.h"
#include "icalerror_p.h"
#include "icalpvl_p.h"
#include "icalvalue.h"

#include <stddef.h> /* for ptrdiff_t */
#include <stdlib.h>

/// @cond PRIVATE
extern int ssparse(void);
extern char *input_buffer;
extern char *input_buffer_p;

struct icalgauge_impl *icalss_yy_gauge;
/// @endcond

icalgauge *icalgauge_new_from_sql(const char *sql, int expand)
{
    struct icalgauge_impl *impl;
    int r;

    if ((impl = (struct icalgauge_impl *)malloc(sizeof(struct icalgauge_impl))) == 0) {
        icalerror_set_errno(ICAL_NEWFAILED_ERROR);
        return 0;
    }

    impl->select = icalpvl_newlist();
    impl->from = icalpvl_newlist();
    impl->where = icalpvl_newlist();
    impl->expand = expand;

    icalss_yy_gauge = impl;
    input_buffer = input_buffer_p = (char *)sql;

    r = ssparse();

    if (r == 0) {
        return impl;
    } else {
        icalgauge_free(impl);
        return NULL;
    }
}

int icalgauge_get_expand(const icalgauge *gauge)
{
    icalerror_check_arg_rz((gauge != 0), "gauge");
    return gauge->expand;
}

void icalgauge_free(icalgauge *gauge)
{
    struct icalgauge_where *w;

    assert(gauge->select != 0);
    assert(gauge->where != 0);
    assert(gauge->from != 0);

    if (gauge->select) {
        while ((w = icalpvl_pop(gauge->select)) != 0) {
            if (w->value != 0) {
                free(w->value);
            }
            free(w);
        }
        icalpvl_free(gauge->select);
        gauge->select = 0;
    }

    if (gauge->where) {
        while ((w = icalpvl_pop(gauge->where)) != 0) {
            if (w->value != 0) {
                free(w->value);
            }
            free(w);
        }
        icalpvl_free(gauge->where);
        gauge->where = 0;
    }

    if (gauge->from) {
        icalpvl_free(gauge->from);
        gauge->from = 0;
    }

    free(gauge);
}

/// @cond PRIVATE
/*non-static,recursive*/
int icalgauge_compare_recurse(icalcomponent *comp, icalcomponent *gauge)
{
    int pass = 1, localpass = 0;
    icalproperty *p;
    icalcomponent *child, *subgauge;
    icalcomponent_kind gaugekind, compkind;

    icalerror_check_arg_rz((comp != 0), "comp");
    icalerror_check_arg_rz((gauge != 0), "gauge");

    gaugekind = icalcomponent_isa(gauge);
    compkind = icalcomponent_isa(comp);

    if (!(gaugekind == compkind || gaugekind == ICAL_ANY_COMPONENT)) {
        return 0;
    }

    /* Test properties. For each property in the gauge, search through
       the component for a similar property. If one is found, compare
       the two properties value with the comparison specified in the
       gauge with the X-LIC-COMPARETYPE parameter */

    for (p = icalcomponent_get_first_property(gauge, ICAL_ANY_PROPERTY);
         p != 0;
         p = icalcomponent_get_next_property(gauge, ICAL_ANY_PROPERTY)) {
        icalproperty *targetprop;
        icalparameter *compareparam;
        icalparameter_xliccomparetype compare;

        /* Extract the comparison type from the gauge. If there is no
           comparison type, assume that it is "EQUAL" */

        compareparam = icalproperty_get_first_parameter(p, ICAL_XLICCOMPARETYPE_PARAMETER);

        if (compareparam != 0) {
            compare = icalparameter_get_xliccomparetype(compareparam);
        } else {
            compare = ICAL_XLICCOMPARETYPE_EQUAL;
        }

        /* Find a property in the component that has the same type
           as the gauge property. HACK -- multiples of a single
           property type in the gauge will match only the first
           instance in the component */

        targetprop = icalcomponent_get_first_property(comp, icalproperty_isa(p));

        if (targetprop != 0) {
            /* Compare the values of the gauge property and the target
               property */

            /* The relationship between the gauge and target values */
            icalparameter_xliccomparetype rel = icalvalue_compare(icalproperty_get_value(p), icalproperty_get_value(targetprop));

            /* Now see if the comparison is equivalent to the comparison
               specified in the gauge */

            if (rel == ICAL_XLICCOMPARETYPE_NONE || compare == ICAL_XLICCOMPARETYPE_NONE) {
                localpass = 0;
            } else if (rel == compare) {
                localpass++;
            } else if (compare == ICAL_XLICCOMPARETYPE_LESSEQUAL &&
                       (rel == ICAL_XLICCOMPARETYPE_LESS || rel == ICAL_XLICCOMPARETYPE_EQUAL)) {
                localpass++;
            } else if (compare == ICAL_XLICCOMPARETYPE_GREATEREQUAL &&
                       (rel == ICAL_XLICCOMPARETYPE_GREATER || rel == ICAL_XLICCOMPARETYPE_EQUAL)) {
                localpass++;
            } else if (compare == ICAL_XLICCOMPARETYPE_NOTEQUAL &&
                       (rel == ICAL_XLICCOMPARETYPE_GREATER || rel == ICAL_XLICCOMPARETYPE_LESS)) {
                localpass++;
            } else {
                localpass = 0;
            }

            pass = pass && (localpass > 0);
        }
    }

    /* Test subcomponents. Look for a child component that has a
       counterpart in the gauge. */

    for (subgauge = icalcomponent_get_first_component(gauge, ICAL_ANY_COMPONENT);
         subgauge != 0;
         subgauge = icalcomponent_get_next_component(gauge, ICAL_ANY_COMPONENT)) {
        gaugekind = icalcomponent_isa(subgauge);

        if (gaugekind == ICAL_ANY_COMPONENT) {
            child = icalcomponent_get_first_component(comp, ICAL_ANY_COMPONENT);
        } else {
            child = icalcomponent_get_first_component(comp, gaugekind);
        }

        if (child != 0) {
            localpass = icalgauge_compare_recurse(child, subgauge);
            pass = pass && localpass;
        } else {
            pass = 0;
        }
    }

    return pass;
}
/// @endcond

bool icalgauge_compare(icalgauge *gauge, icalcomponent *comp)
{
    icalcomponent *inner;
    int local_pass = 0;
    bool last_clause = true;
    icalpvl_elem e;
    int compare_recur = 0;

    icalerror_check_arg_rz((comp != 0), "comp");
    icalerror_check_arg_rz((gauge != 0), "gauge");

    inner = icalcomponent_get_first_real_component(comp);

    if (inner == 0) {
        /* Wally Yau: our component is not always wrapped with
         * a <VCALENDAR>. It's not an error.
         * icalerror_set_errno(ICAL_MALFORMEDDATA_ERROR);
         * return false; */
        icalcomponent_kind kind = icalcomponent_isa(comp);
        if (kind == ICAL_VEVENT_COMPONENT ||
            kind == ICAL_VTODO_COMPONENT ||
            kind == ICAL_VJOURNAL_COMPONENT ||
            kind == ICAL_VQUERY_COMPONENT || kind == ICAL_VAGENDA_COMPONENT) {
            inner = comp;
        } else {
            icalerror_set_errno(ICAL_MALFORMEDDATA_ERROR);
            return false;
        }
    }

    /* Check that this component is one of the FROM types */
    local_pass = 0;
    for (e = icalpvl_head(gauge->from); e != 0; e = icalpvl_next(e)) {
        icalcomponent_kind k = (icalcomponent_kind)(ptrdiff_t)icalpvl_data(e);

        if (k == icalcomponent_isa(inner)) {
            local_pass = 1;
        }
    }

    if (local_pass == 0) {
        return false;
    }

    /**** Check each where clause against the component ****/
    for (e = icalpvl_head(gauge->where); e != 0; e = icalpvl_next(e)) {
        struct icalgauge_where *w = icalpvl_data(e);
        icalcomponent *sub_comp;
        icalvalue *v;
        icalproperty *prop;
        icalvalue_kind vk;

        if (!w || w->prop == ICAL_NO_PROPERTY || w->value == 0) {
            icalerror_set_errno(ICAL_INTERNAL_ERROR);
            return false;
        }

        /* First, create a value from the gauge */
        vk = icalproperty_kind_to_value_kind(w->prop);

        if (vk == ICAL_NO_VALUE) {
            icalerror_set_errno(ICAL_INTERNAL_ERROR);
            return false;
        }

        if (w->compare == ICALGAUGECOMPARE_ISNULL || w->compare == ICALGAUGECOMPARE_ISNOTNULL) {
            v = icalvalue_new(vk);
        } else {
            v = icalvalue_new_from_string(vk, w->value);
        }

        if (v == 0) {
            /* Keep error set by icalvalue_from-string */
            return false;
        }

        /* Now find the corresponding property in the component,
           descending into a sub-component if necessary */

        if (w->comp == ICAL_NO_COMPONENT) {
            sub_comp = inner;
        } else {
            sub_comp = icalcomponent_get_first_component(inner, w->comp);
            if (sub_comp == 0) {
                icalvalue_free(v);
                return false;
            }
        }

        /* check if it is a recurring */
        const icalproperty *rrule = icalcomponent_get_first_property(sub_comp, ICAL_RRULE_PROPERTY);

        if (gauge->expand && rrule) {
            if (w->prop == ICAL_DTSTART_PROPERTY ||
                w->prop == ICAL_DTEND_PROPERTY || w->prop == ICAL_DUE_PROPERTY) {
                /** needs to use recurrence-id to do comparison */
                compare_recur = 1;
            }
        }

        local_pass = (w->compare == ICALGAUGECOMPARE_ISNULL) ? 1 : 0;

        for (prop = icalcomponent_get_first_property(sub_comp, w->prop);
             prop != 0;
             prop = icalcomponent_get_next_property(sub_comp, w->prop)) {
            icalvalue *prop_value;
            icalgaugecompare relation;

            if (w->compare == ICALGAUGECOMPARE_ISNULL) {
                local_pass = 0;
                break;
            }

            if (w->compare == ICALGAUGECOMPARE_ISNOTNULL) {
                local_pass = 1;
                break;
            }

            if (compare_recur) {
                icalproperty *p =
                    icalcomponent_get_first_property(sub_comp, ICAL_RECURRENCEID_PROPERTY);
                prop_value = icalproperty_get_value(p);
            } else { /* prop value from this component */
                prop_value = icalproperty_get_value(prop);
            }

            relation = (icalgaugecompare)icalvalue_compare(prop_value, v);

            if (relation == w->compare) {
                local_pass++;
            } else if (w->compare == ICALGAUGECOMPARE_LESSEQUAL &&
                       (relation == ICALGAUGECOMPARE_LESS || relation == ICALGAUGECOMPARE_EQUAL)) {
                local_pass++;
            } else if (w->compare == ICALGAUGECOMPARE_GREATEREQUAL &&
                       (relation == ICALGAUGECOMPARE_GREATER ||
                        relation == ICALGAUGECOMPARE_EQUAL)) {
                local_pass++;
            } else if (w->compare == ICALGAUGECOMPARE_NOTEQUAL &&
                       (relation == ICALGAUGECOMPARE_GREATER ||
                        relation == ICALGAUGECOMPARE_LESS)) {
                local_pass++;
            } else {
                local_pass = 0;
            }
        }

        bool this_clause = (local_pass > 0);

        /* Now look at the logic operator for this clause to see how
           the value should be merge with the previous clause */

        if (w->logic == ICALGAUGELOGIC_AND) {
            last_clause = this_clause && last_clause;
        } else if (w->logic == ICALGAUGELOGIC_OR) {
            last_clause = this_clause || last_clause;
        } else {
            last_clause = this_clause;
        }

        icalvalue_free(v);

    } /**** check next one in where clause ****/

    return last_clause;
}

void icalgauge_dump(icalgauge *gauge)
{
    icalpvl_elem p;

    printf("--- Select ---\n");
    for (p = icalpvl_head(gauge->select); p != 0; p = icalpvl_next(p)) {
        struct icalgauge_where *w = icalpvl_data(p);

        if (!w) {
            continue;
        }

        if (w->comp != ICAL_NO_COMPONENT) {
            printf("%s ", icalcomponent_kind_to_string(w->comp));
        }

        if (w->prop != ICAL_NO_PROPERTY) {
            printf("%s ", icalproperty_kind_to_string(w->prop));
        }

        if (w->compare != ICALGAUGECOMPARE_NONE) {
            printf("%d ", w->compare);
        }

        if (w->value != 0) {
            printf("%s", w->value);
        }

        printf("\n");
    }

    printf("--- From ---\n");
    for (p = icalpvl_head(gauge->from); p != 0; p = icalpvl_next(p)) {
        icalcomponent_kind k = (icalcomponent_kind)(ptrdiff_t)icalpvl_data(p);

        printf("%s\n", icalcomponent_kind_to_string(k));
    }

    printf("--- Where ---\n");
    for (p = icalpvl_head(gauge->where); p != 0; p = icalpvl_next(p)) {
        struct icalgauge_where *w = icalpvl_data(p);

        if (!w) {
            continue;
        }

        if (w->logic != ICALGAUGELOGIC_NONE) {
            printf("%d ", w->logic);
        }

        if (w->comp != ICAL_NO_COMPONENT) {
            printf("%s ", icalcomponent_kind_to_string(w->comp));
        }

        if (w->prop != ICAL_NO_PROPERTY) {
            printf("%s ", icalproperty_kind_to_string(w->prop));
        }

        if (w->compare != ICALGAUGECOMPARE_NONE) {
            printf("%d ", w->compare);
        }

        if (w->value != 0) {
            printf("%s", w->value);
        }

        printf("\n");
    }
}
